*** To compile ***
gcc -o smallsh smallsh.c

